# NSWpedia Source

Sorgente per scaricare ROM Nintendo Switch da [NSWpedia.com](https://nswpedia.com/).

## Caratteristiche

- ✅ Ricerca ROM per titolo
- ✅ Download multipli (NSP, XCI)
- ✅ Supporto WebView per link di download esterni
- ✅ Solo piattaforma Nintendo Switch

## Note

- I link di download richiedono l'apertura di un WebView per ottenere l'URL finale
- Placeholder immagine: `nswpedia/placeholder.png`

